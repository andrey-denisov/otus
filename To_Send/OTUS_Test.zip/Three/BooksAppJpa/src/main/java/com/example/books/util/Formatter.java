package com.example.books.util;

public interface Formatter<T> {
    String format(T value);
}

package org.example.exam.io;

// интерфейс для отображения информации пользователю
public interface Display {
    void display(String message);
}

package org.example.exam.io;

// интерфейс для получения данных от пользователя
public interface UserInput {
    String getUserInput();
}
